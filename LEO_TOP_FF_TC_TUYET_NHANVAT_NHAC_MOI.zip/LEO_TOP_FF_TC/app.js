const $=s=>document.querySelector(s), toast=t=>{const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2800)};
const getUsers=()=>JSON.parse(localStorage.getItem("ff_users")||"[]");
const getOrders=()=>JSON.parse(localStorage.getItem("ff_orders")||"[]");
let currentUser=localStorage.getItem("ff_current_user")||"", authMode="login", currentOrderId="";
function openAuth(mode){authMode=mode;$("#modalTitle").textContent=mode==="login"?"ĐĂNG NHẬP":"TẠO TÀI KHOẢN";$("#authSubmit").textContent=mode==="login"?"ĐĂNG NHẬP":"ĐĂNG KÝ";$("#switchAuth").innerHTML=mode==="login"?'Chưa có tài khoản? <button type="button">Đăng ký</button>':'Đã có tài khoản? <button type="button">Đăng nhập</button>';$("#modal").classList.add("show")}
function refresh(){const b=$("#accountNav");b.innerHTML=(currentUser?"♙":"♙")+`<small>${currentUser?"Tài khoản":"Tài khoản"}</small>`;const list=$("#ordersList");if(!currentUser){list.className="empty-state";list.textContent="Đăng nhập để xem các đơn đã tạo trên thiết bị này.";return}const orders=getOrders().filter(o=>o.owner===currentUser);if(!orders.length){list.className="empty-state";list.textContent="Bạn chưa có đơn đăng ký nào.";return}list.className="";list.innerHTML=orders.map(o=>`<div class="order-item"><span><b>${o.id}</b> · ${o.player} · UID ${o.uid}</span><span class="status">${o.status}</span></div>`).join("")}
$("#openLogin").onclick=()=>openAuth("login");$("#openRegister").onclick=()=>openAuth("register");$("#accountNav").onclick=()=>currentUser?(localStorage.removeItem("ff_current_user"),currentUser="",refresh(),toast("Đã đăng xuất")):openAuth("login");
$("#closeModal").onclick=()=>$("#modal").classList.remove("show");$("#switchAuth").onclick=e=>{if(e.target.tagName==="BUTTON")openAuth(authMode==="login"?"register":"login")};
$("#authForm").onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target),id=fd.get("identity").trim().toLowerCase(),pw=fd.get("password"),users=getUsers();if(authMode==="register"){if(users.some(u=>u.id===id)){toast("Tài khoản đã tồn tại trên trình duyệt này.");return}users.push({id,pw});localStorage.setItem("ff_users",JSON.stringify(users));toast("Tạo tài khoản demo thành công.")}else if(!users.some(u=>u.id===id&&u.pw===pw)){toast("Thông tin đăng nhập không đúng hoặc chưa có tài khoản.");return}currentUser=id;localStorage.setItem("ff_current_user",id);$("#modal").classList.remove("show");e.target.reset();refresh();toast("Đăng nhập thành công.")};
$("#orderForm").onsubmit=e=>{e.preventDefault();if(!currentUser){toast("Vui lòng đăng nhập hoặc đăng ký trước.");openAuth("register");return}const fd=new FormData(e.target),o={id:"FFTC-"+Date.now().toString().slice(-7),owner:currentUser,player:fd.get("player"),uid:fd.get("uid"),email:fd.get("email"),phone:fd.get("phone"),package:fd.get("package"),status:"Chờ thanh toán / Admin duyệt"};const orders=getOrders();orders.unshift(o);localStorage.setItem("ff_orders",JSON.stringify(orders));currentOrderId=o.id;refresh();toast("Đã tạo đơn demo. Kiểm tra thông tin QR trước khi chuyển khoản.");$("#payment").scrollIntoView({behavior:"smooth"})};
$("#showBill").onclick=()=>{if(!currentUser){openAuth("login");return}$("#billModal").classList.add("show")};$("#closeBill").onclick=()=>$("#billModal").classList.remove("show");
$("#sendBill").onclick=()=>{const ref=$("#billRef").value.trim();if(!ref){toast("Nhập mã giao dịch hoặc nội dung chuyển khoản.");return}let orders=getOrders();const o=orders.find(x=>x.owner===currentUser&&x.id===currentOrderId)||orders.find(x=>x.owner===currentUser);if(o){o.billRef=ref;o.status="Đã gửi thông tin bill — chờ Admin kiểm tra";localStorage.setItem("ff_orders",JSON.stringify(orders));refresh()}$("#billModal").classList.remove("show");toast("Đã lưu thông tin bill trên thiết bị. Hãy gửi ảnh bill cho Admin qua Telegram.")};
refresh();

const music=$("#bgMusic"), musicBtn=$("#musicToggle");
if(musicBtn && music){
  music.volume=0.22;
  musicBtn.onclick=async()=>{
    try{
      if(music.paused){await music.play();musicBtn.textContent="♫ TẮT NHẠC";musicBtn.classList.add("is-playing");musicBtn.setAttribute("aria-pressed","true")}
      else{music.pause();musicBtn.textContent="♫ BẬT NHẠC";musicBtn.classList.remove("is-playing");musicBtn.setAttribute("aria-pressed","false")}
    }catch(e){toast("Trình duyệt chưa cho phát nhạc. Hãy thử nhấn lại.")}
  };
}

// Gentle snowfall overlay. Respects reduced-motion preferences.
(()=>{
  const canvas=document.getElementById("snowCanvas");
  if(!canvas || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const ctx=canvas.getContext("2d");
  let w=0,h=0,flakes=[];
  const resize=()=>{
    const dpr=Math.min(window.devicePixelRatio||1,2);
    w=window.innerWidth;h=window.innerHeight;
    canvas.width=w*dpr;canvas.height=h*dpr;canvas.style.width=w+"px";canvas.style.height=h+"px";
    ctx.setTransform(dpr,0,0,dpr,0,0);
    flakes=Array.from({length:Math.min(85,Math.floor(w/5))},()=>({
      x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.8+.5,
      speed:Math.random()*.65+.35,drift:Math.random()*.55-.275,alpha:Math.random()*.55+.2
    }));
  };
  let last=0;
  const draw=(time)=>{
    if(time-last>30){
      last=time;ctx.clearRect(0,0,w,h);
      for(const f of flakes){
        f.y+=f.speed;f.x+=f.drift+Math.sin((f.y+f.x)*.008)*.18;
        if(f.y>h+4){f.y=-5;f.x=Math.random()*w}
        if(f.x>w+5)f.x=-5;if(f.x<-5)f.x=w+5;
        ctx.beginPath();ctx.arc(f.x,f.y,f.r,0,Math.PI*2);
        ctx.fillStyle=`rgba(245,235,255,${f.alpha})`;ctx.fill();
      }
    }
    requestAnimationFrame(draw);
  };
  resize();window.addEventListener("resize",resize,{passive:true});requestAnimationFrame(draw);
})();
