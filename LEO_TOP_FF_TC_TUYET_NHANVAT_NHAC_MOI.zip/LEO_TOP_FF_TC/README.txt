LEO TOP FF TC — GÓI GIAO DIỆN DEMO

Cách xem:
1. Giải nén file ZIP.
2. Mở index.html bằng trình duyệt hoặc tải thư mục lên hosting static.
3. Trên điện thoại, nên dùng Safari/Chrome.

Có sẵn:
- Giao diện responsive tối ưu điện thoại.
- Đăng ký/đăng nhập demo bằng email hoặc số điện thoại + mật khẩu.
- Form đăng ký SLOT CỨNG 50.000đ / 4 ngày.
- Hiển thị ảnh QR MB Bank do người dùng cung cấp.
- Lưu đơn và thông tin bill trong localStorage của trình duyệt.
- Nút Telegram và gọi điện hỗ trợ.

QUAN TRỌNG — CHƯA PHẢI HỆ THỐNG THANH TOÁN/ĐĂNG NHẬP THẬT:
- Tài khoản, mật khẩu và đơn hiện chỉ lưu trong trình duyệt trên thiết bị; không có backend, không đồng bộ giữa khách và Admin.
- Không dùng bản demo để thu tiền thật hoặc lưu mật khẩu khách. Cần backend có xác thực an toàn, cơ sở dữ liệu, phân quyền Admin và xác minh giao dịch phía máy chủ trước khi vận hành.
- Nút gửi bill chỉ lưu mã giao dịch ở trình duyệt; khách cần gửi ảnh bill trực tiếp cho Admin.
- QR là ảnh được cung cấp trong cuộc trò chuyện. Hãy tự kiểm tra bằng ứng dụng ngân hàng và xác nhận đúng người nhận/số tài khoản trước khi công khai.
- Website là trang đăng ký độc lập, không đại diện cho Garena/Free Fire. Không yêu cầu mật khẩu hoặc OTP game.

Cấu trúc:
index.html
style.css
app.js
assets/mb-qr.jpeg
README.txt

NHẠC NỀN: Đã thay bằng file nhạc người dùng gửi trong assets/nhac-moi.mp3. Nhấn nút “BẬT NHẠC” để phát/tắt. Trình duyệt iPhone cần người dùng chạm nút mới cho phép phát nhạc.

HIỆU ỨNG MỚI: Có tuyết rơi nhẹ toàn trang và mascot chiến binh cyber nguyên bản chuyển động nhè nhẹ ở khu vực banner. Có tôn trọng cài đặt giảm chuyển động của thiết bị.
